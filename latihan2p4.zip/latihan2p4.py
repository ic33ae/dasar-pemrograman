"""Nama: Ica Apriyanti Rahayu
NIM: 2408415
Kelas: RPL 1B"""

students = {
    "Alice": "Computer Science",
    "Bob": "Mathematics",
    "Charlie": "Physics",
    "David": "Computer Science",
    "Eva": "Mathematics"
}

print("prodi Computer Science sebanyak =",list(students.values()).count("Computer Science"))
print("prodi  Mathematics sebanyak =",list(students.values()).count("Mathematics"))
print("prodi  Physics sebanyak =",list(students.values()).count("Physics"))
"""Nama: Ica Apriyanti Rahayu
NIM: 2408415
Kelas: RPL 1B"""

nomor = [10, 20, 20, 30, 40, 50, 50, 60]
hasil = set(nomor)

print(sorted(hasil))
